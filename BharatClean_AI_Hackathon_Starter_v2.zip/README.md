# BharatClean AI
**Turning Waste into Intelligence. Building a Cleaner Bharat.**

An AI + IoT college-hackathon MVP for waste classification, citizen reporting, smart-bin telemetry, collection operations and recycling exchange.

## Status and honesty
This repository is a starter implementation. The browser app runs in demo mode with seeded illustrative data. Demo sensor readings are simulated; no municipal system, physical device, or external AI model is connected by default. Never present demo readings or placeholder classifications as live results.

## Quick start
This is a zero-build static MVP:
1. Open `app/index.html` in a modern browser, or serve the folder with any static HTTP server.
2. Switch the Demo Role in the top bar to explore Citizen, Collector and Municipal Admin experiences.
3. Use the navigation to submit a complaint, inspect simulated bins, classify a sample waste item, assign collection tasks and create a recycling listing.

For deployment, host the `app/` folder on Netlify, Vercel static hosting, GitHub Pages or any static host.

## Architecture
- `app/`: responsive single-page interactive MVP (no credentials required).
- `supabase/migrations/`: PostgreSQL schema, indexes and starter RLS policies.
- `firmware/esp32_smartbin/`: ESP32 Arduino sketch for ultrasonic fill-level telemetry.
- `docs/`: AI, IoT, validation and demo notes.

## Planned production stack
Next.js + TypeScript, Supabase Auth/Postgres/Storage, PostGIS, YOLOv8/YOLO11 or another evaluated vision model, an LLM for grounded disposal guidance, ESP32 + ultrasonic sensor, MQTT/HTTPS ingestion, Leaflet/OpenStreetMap and OR-Tools.

## IoT payload contract
POST telemetry to an authenticated ingestion endpoint:
```json
{
  "device_id": "BC-PAT-001",
  "fill_percent": 76.4,
  "temperature_c": 31.2,
  "battery_percent": 92,
  "recorded_at": "2026-10-01T10:30:00Z",
  "source": "live"
}
```
The endpoint must authenticate the device, validate ranges, map `device_id` to a registered bin, and store a reading. Do not embed service-role keys in firmware or browser code.

## Fill calculation
`fill_percent = clamp((bin_depth_cm - measured_distance_cm) / bin_depth_cm * 100, 0, 100)`

Calibrate the ultrasonic sensor with an empty bin and a known fill level. Ignore impossible readings and apply a short rolling median to reduce noise.

## AI pipeline
1. Validate MIME type and file size; resize/crop consistently.
2. Run a trained vision model on a supported set of classes.
3. Return category, confidence, model version and timestamp.
4. If confidence is below the evaluated threshold, return `unknown` and request manual review.
5. Generate disposal guidance from a reviewed local ruleset; LLM output must not override hazardous-waste safety instructions.
6. Persist the inference with `is_demo=false` only when a real model actually ran.

Suggested initial classes: wet/organic, dry paper/cardboard, plastic, metal, glass, e-waste, sanitary/hazardous and unknown. Build a labelled dataset with consent and documented provenance. Report per-class precision, recall, F1 and confusion matrix; do not claim accuracy before evaluation.

## Routing and overflow
The demo uses transparent thresholds and a nearest-first heuristic. It is not a learned prediction model and does not guarantee an optimal route. Production routing should account for vehicle capacity, road network, time windows, bin priority and disposal-site constraints; evaluate with OR-Tools and real operational data.

## Privacy and safety
Collect only necessary data. Make location optional where possible. Strip image metadata, restrict access to complaint images, avoid publishing personal contact details, and apply RLS. Use synthetic/illustrative Patna locality data until official datasets and permissions are available.

## Hardware
ESP32 DevKit + HC-SR04 ultrasonic sensor (use a voltage divider on the Echo pin because ESP32 GPIO is 3.3V) + optional DS18B20 temperature sensor. The included sketch prints JSON to Serial; configure Wi-Fi and an authenticated endpoint before live transmission.

## Hackathon demo script (4–5 minutes)
1. Show dashboard and state clearly that seeded records are demo data.
2. As a citizen, submit a garbage complaint with locality and category.
3. Switch to admin; triage the complaint and create/assign a pickup task.
4. Open SmartBin IoT; explain the ESP32 sensor and demonstrate simulated telemetry, clearly labelled.
5. Open BharatVision; demonstrate the sample classifier and explain the real-model integration boundary.
6. Create a recyclable listing and show the circular-economy flow.
7. Show schema, RLS, device payload and firmware in the public repository.

## Submission checklist
- Public GitHub repository with this README, app, schema, firmware and circuit diagram.
- Demo video showing the end-to-end app and hardware prototype.
- System design walkthrough video.
- Evidence of physical sensor working, if hardware is claimed.
- Screenshots and test records; disclose what is simulated.
- Remove secrets, personal data and unlicensed assets before submission.
