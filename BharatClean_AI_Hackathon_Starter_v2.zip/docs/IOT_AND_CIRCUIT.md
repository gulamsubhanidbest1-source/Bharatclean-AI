# SmartBin prototype — circuit and data contract

## Bill of materials
- ESP32 DevKit (3.3V GPIO)
- HC-SR04 ultrasonic distance sensor
- Breadboard and jumper wires
- Resistors for Echo voltage divider (example 1kΩ and 2kΩ)
- Optional DS18B20 temperature sensor with suitable pull-up resistor
- USB power bank / regulated supply
- Bin enclosure and sensor mounting bracket

## Wiring
- HC-SR04 VCC → 5V
- HC-SR04 GND → GND
- TRIG → GPIO 5
- ECHO → resistor divider → GPIO 18
- Never connect 5V Echo directly to ESP32 GPIO.

## Measurement
Mount the sensor at the top, pointing down. Measure internal bin depth with the bin empty. Compute fill percentage from measured distance. Calibrate with known fill levels; test angled surfaces and irregular waste. Use median filtering and reject timeout/out-of-range readings.

## Telemetry
Device payload should include device_id, fill_percent, temperature_c (nullable), battery_percent (nullable), recorded_at and source. Authenticate each device using a revocable device credential held outside public client code. Use TLS in production.
