# No-hardware path: virtual prototype now, physical prototype later

The team currently has no hardware. Do not present simulated telemetry as physical sensor data.

## Phase A — virtual sensor
Run `python tools/sensor_simulator.py --count 20 --interval 2`. It emits JSON using the same telemetry contract as ESP32. Every record is labelled `source: demo`.

## Phase B — minimum physical build
Indicative India purchase budget (verify current local prices):
- ESP32 DevKit V1: ₹350–₹600
- HC-SR04 ultrasonic sensor: ₹60–₹120
- Breadboard and jumper wires: ₹100–₹180
- 1kΩ + 2kΩ resistors for Echo divider: ₹10–₹30
- USB cable / power bank if not already available

Indicative total: ₹520–₹930 excluding delivery and power supply. Optional waterproof ultrasonic sensor costs more.

## Phase C — physical validation
1. Mount sensor at top of a test container.
2. Record empty, 25%, 50%, 75% and near-full readings.
3. Take at least 10 readings per level.
4. Calculate mean absolute error and repeatability.
5. Test uneven waste surfaces and timeouts.
6. Record physical sensor, Serial Monitor JSON and dashboard in one demo.

Only use `source=live` when a registered physical device produced the reading.
