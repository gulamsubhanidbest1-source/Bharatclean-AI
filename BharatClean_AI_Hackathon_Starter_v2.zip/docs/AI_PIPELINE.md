# BharatVision AI — model and evaluation plan

## MVP boundary
The included web prototype uses a deterministic sample selector to demonstrate user flow. It does not inspect uploaded pixels and must never be described as a trained classifier.

## Production inference contract
Input: image bytes, content type, optional coarse locality and user consent.
Output:
```json
{
  "category": "plastic",
  "confidence": 0.87,
  "model_version": "bharatvision-yolo-v0.1",
  "is_demo": false,
  "review_required": false
}
```

## Pipeline
1. Validate file type, size and dimensions; reject unsupported or corrupt files.
2. Remove EXIF metadata and resize using the model's documented preprocessing.
3. Run object detection/classification.
4. Apply per-class confidence thresholds chosen on validation data.
5. If uncertain, return `unknown` and route to human review.
6. Provide disposal guidance from a curated ruleset. Keep battery, e-waste, biomedical and hazardous guidance conservative.
7. Persist category, confidence, model version and provenance.

## Dataset and evaluation
Build a legally usable, consented and documented dataset covering local lighting, camera angles, packaging and contamination. Split by source/location to reduce leakage. Report precision, recall, macro-F1, per-class confusion matrix and latency. Evaluate class imbalance and unknown detection. Do not publish accuracy claims until measured on a held-out test set.
