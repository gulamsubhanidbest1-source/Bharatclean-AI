# Publish the project to GitHub

The connected GitHub account is authenticated as `gulamsubhanidbest1-source`. The initial repository listing returned no repositories. The available GitHub connection supports file/commit operations but does not expose repository creation.

## Create the public repository
1. Open https://github.com/new
2. Repository name: `bharatclean-ai`
3. Description: `AI + IoT waste management ecosystem for a cleaner Bharat`
4. Choose **Public**.
5. Do not initialise with README, .gitignore or license.
6. Create repository.

## Push the starter
Extract the ZIP, open a terminal in the extracted `bharatclean-ai` directory:
```bash
git init
git add .
git commit -m "Initial BharatClean AI MVP"
git branch -M main
git remote add origin https://github.com/gulamsubhanidbest1-source/bharatclean-ai.git
git push -u origin main
```
Use GitHub browser sign-in or a personal access token if prompted. Never paste tokens into chat or commit them.

After creation, share the repository URL here so connected GitHub tools can update files and commits.
