# Hackathon delivery plan

Deadline from supplied brief: 10 October 2026, 8:00 PM IST.

## Build sequence
- Oct 1–2: run the MVP, settle the problem narrative, finalise circuit and source hardware.
- Oct 3–4: assemble ESP32 + ultrasonic prototype; record serial measurements; calibrate empty/half/full.
- Oct 5–6: connect a secure ingestion endpoint if backend credentials and hosting are available; otherwise demonstrate serial telemetry and keep dashboard explicitly in simulated mode.
- Oct 7: validate citizen report → admin triage → collection task workflow.
- Oct 8: test app on mobile and desktop; prepare README, circuit diagram and architecture diagram.
- Oct 9: record two videos: end-to-end demo and system-design walkthrough.
- Oct 10: final QA, remove secrets/personal data, verify public repository and submit before 8 PM IST.

## Demo narrative (5 minutes)
1. Problem and product in 30 seconds.
2. Citizen reports a waste issue.
3. Admin triages it and assigns a pickup.
4. Smart bin sensor demonstrates distance-to-fill calculation.
5. BharatVision flow explains the model and its current demo boundary.
6. Recycler listing shows circular-economy workflow.
7. Architecture, privacy, RLS and deployment roadmap.

## Evidence judges can inspect
- Public source repository.
- Working browser MVP.
- ESP32 serial output and physical fill-level test.
- Wiring diagram and calibration notes.
- SQL schema and security model.
- Honest AI evaluation plan and explicit demo/live labels.
