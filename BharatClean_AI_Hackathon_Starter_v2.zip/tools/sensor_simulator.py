#!/usr/bin/env python3
import argparse, json, random, time
from datetime import datetime, timezone
p=argparse.ArgumentParser(description="BharatClean virtual smart-bin sensor")
p.add_argument("--device-id",default="BC-PAT-VIRTUAL-001")
p.add_argument("--depth-cm",type=float,default=80)
p.add_argument("--interval",type=float,default=5)
p.add_argument("--count",type=int,default=10)
a=p.parse_args()
fill=random.uniform(25,45)
for _ in range(a.count):
    fill=max(0,min(100,fill+random.uniform(-1.5,4.0)))
    print(json.dumps({"device_id":a.device_id,"fill_percent":round(fill,1),
      "distance_cm":round(a.depth_cm*(1-fill/100),1),
      "temperature_c":round(random.uniform(27,36),1),
      "battery_percent":round(random.uniform(85,100),1),
      "recorded_at":datetime.now(timezone.utc).isoformat(),"source":"demo"}),flush=True)
    time.sleep(a.interval)
