-- BharatClean AI starter schema. Review and adapt before production deployment.
create extension if not exists pgcrypto;
create extension if not exists postgis;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  role text not null default 'citizen' check (role in ('citizen','collector','admin','recycler')),
  phone text,
  ward text,
  created_at timestamptz not null default now()
);

create table if not exists public.wards (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  city text not null default 'Patna',
  state text not null default 'Bihar',
  boundary_geojson jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.bins (
  id uuid primary key default gen_random_uuid(),
  device_id text unique not null,
  name text not null,
  ward_id uuid references public.wards(id),
  latitude double precision,
  longitude double precision,
  capacity_litres integer check (capacity_litres > 0),
  status text not null default 'active' check (status in ('active','maintenance','inactive')),
  last_seen_at timestamptz,
  created_at timestamptz not null default now(),
  check (latitude is null or latitude between -90 and 90),
  check (longitude is null or longitude between -180 and 180)
);

create table if not exists public.bin_readings (
  id bigint generated always as identity primary key,
  bin_id uuid not null references public.bins(id) on delete cascade,
  fill_percent numeric(5,2) not null check (fill_percent between 0 and 100),
  temperature_c numeric(5,2),
  battery_percent numeric(5,2) check (battery_percent is null or battery_percent between 0 and 100),
  recorded_at timestamptz not null default now(),
  source text not null default 'live' check (source in ('demo','live'))
);
create index if not exists bin_readings_bin_time_idx on public.bin_readings(bin_id, recorded_at desc);

create table if not exists public.complaints (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid references public.profiles(id) on delete set null,
  ward_id uuid references public.wards(id),
  category text not null,
  description text not null,
  image_url text,
  latitude double precision,
  longitude double precision,
  status text not null default 'open' check (status in ('open','assigned','in_progress','resolved','rejected')),
  priority text not null default 'medium' check (priority in ('low','medium','high','critical')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists complaints_status_created_idx on public.complaints(status, created_at desc);

create table if not exists public.collection_tasks (
  id uuid primary key default gen_random_uuid(),
  bin_id uuid references public.bins(id),
  complaint_id uuid references public.complaints(id),
  assigned_to uuid references public.profiles(id),
  status text not null default 'pending' check (status in ('pending','assigned','in_progress','completed','cancelled')),
  priority text not null default 'medium' check (priority in ('low','medium','high','critical')),
  scheduled_at timestamptz,
  completed_at timestamptz,
  created_at timestamptz not null default now(),
  check (bin_id is not null or complaint_id is not null)
);

create table if not exists public.waste_classifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete set null,
  image_url text,
  predicted_category text not null,
  confidence numeric(5,4) check (confidence is null or confidence between 0 and 1),
  model_version text,
  is_demo boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.recycling_listings (
  id uuid primary key default gen_random_uuid(),
  seller_id uuid references public.profiles(id) on delete set null,
  material text not null,
  description text,
  weight_kg numeric(10,2) not null check (weight_kg > 0),
  indicative_price_inr numeric(10,2) check (indicative_price_inr is null or indicative_price_inr >= 0),
  locality text not null,
  status text not null default 'available' check (status in ('available','requested','matched','collected','closed')),
  created_at timestamptz not null default now()
);

create table if not exists public.recycling_requests (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references public.recycling_listings(id) on delete cascade,
  requester_id uuid references public.profiles(id) on delete set null,
  status text not null default 'requested' check (status in ('requested','accepted','rejected','completed','cancelled')),
  created_at timestamptz not null default now()
);

-- RLS is enabled by default. Production policies should be reviewed against actual
-- role provisioning and municipal operating agreements before launch.
alter table public.profiles enable row level security;
alter table public.wards enable row level security;
alter table public.bins enable row level security;
alter table public.bin_readings enable row level security;
alter table public.complaints enable row level security;
alter table public.collection_tasks enable row level security;
alter table public.waste_classifications enable row level security;
alter table public.recycling_listings enable row level security;
alter table public.recycling_requests enable row level security;

-- A user can read and update their own profile; role changes must be server-controlled.
create policy "profile read own" on public.profiles for select to authenticated using (id = auth.uid());
create policy "profile update own" on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

-- Reference/operational data is readable by authenticated users in this pilot.
create policy "wards read authenticated" on public.wards for select to authenticated using (true);
create policy "bins read authenticated" on public.bins for select to authenticated using (true);
create policy "bin readings read authenticated" on public.bin_readings for select to authenticated using (true);

-- Citizens can create a report as themselves and read their own reports.
create policy "complaints insert own" on public.complaints for insert to authenticated
  with check (reporter_id = auth.uid());
create policy "complaints read own" on public.complaints for select to authenticated
  using (reporter_id = auth.uid());

-- Users can read their own AI history.
create policy "classifications read own" on public.waste_classifications for select to authenticated
  using (user_id = auth.uid());
create policy "classifications insert own" on public.waste_classifications for insert to authenticated
  with check (user_id = auth.uid());

-- Listings are visible to authenticated users; sellers manage their own listing.
create policy "listings read authenticated" on public.recycling_listings for select to authenticated using (true);
create policy "listings insert own" on public.recycling_listings for insert to authenticated
  with check (seller_id = auth.uid());
create policy "listings update own" on public.recycling_listings for update to authenticated
  using (seller_id = auth.uid()) with check (seller_id = auth.uid());

create policy "requests read participant" on public.recycling_requests for select to authenticated
  using (requester_id = auth.uid() or exists (
    select 1 from public.recycling_listings l
    where l.id = listing_id and l.seller_id = auth.uid()
  ));
create policy "requests insert own" on public.recycling_requests for insert to authenticated
  with check (requester_id = auth.uid());

-- IMPORTANT: collection_tasks and admin status changes intentionally have no broad
-- client policies here. Implement privileged operations via audited server-side
-- functions after defining trusted role claims. Never let users self-assign admin.
