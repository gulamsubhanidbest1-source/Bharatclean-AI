import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-device-token", "Access-Control-Allow-Methods": "POST, OPTIONS" };
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return Response.json({error:"Method not allowed"}, {status:405,headers:cors});
  const expected = Deno.env.get("DEVICE_API_TOKEN");
  const supplied = req.headers.get("x-device-token");
  if (!expected || !supplied || supplied !== expected) return Response.json({error:"Unauthorized device"}, {status:401,headers:cors});
  let body;
  try { body = await req.json(); } catch { return Response.json({error:"Invalid JSON"},{status:400,headers:cors}); }
  const fill = Number(body.fill_percent);
  const temp = body.temperature_c == null ? null : Number(body.temperature_c);
  const battery = body.battery_percent == null ? null : Number(body.battery_percent);
  if (typeof body.device_id !== "string" || body.device_id.length < 3 || !Number.isFinite(fill) || fill < 0 || fill > 100 ||
      (temp !== null && (!Number.isFinite(temp) || temp < -20 || temp > 100)) ||
      (battery !== null && (!Number.isFinite(battery) || battery < 0 || battery > 100))
  ) return Response.json({error:"Invalid telemetry values"},{status:422,headers:cors});
  const url = Deno.env.get("SUPABASE_URL"), key = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!url || !key) return Response.json({error:"Server is not configured"},{status:500,headers:cors});
  const db = createClient(url,key);
  const {data:bin,error:lookupError} = await db.from("bins").select("id").eq("device_id",body.device_id).maybeSingle();
  if (lookupError || !bin) return Response.json({error:"Unknown device"},{status:404,headers:cors});
  const {error} = await db.from("bin_readings").insert({bin_id:bin.id,fill_percent:fill,temperature_c:temp,battery_percent:battery,recorded_at:body.recorded_at || new Date().toISOString(),source:"live"});
  if (error) return Response.json({error:"Could not save reading"},{status:500,headers:cors});
  await db.from("bins").update({last_seen_at:new Date().toISOString()}).eq("id",bin.id);
  return Response.json({ok:true,device_id:body.device_id},{headers:cors});
});
