-- Synthetic development data only; not official city data.
insert into public.wards (name, city, state) values
('Kankarbagh Demo Ward','Patna','Bihar'),
('Rajendra Nagar Demo Ward','Patna','Bihar'),
('Patna City Demo Ward','Patna','Bihar');
