/*
 * BharatClean AI — ESP32 + HC-SR04 starter firmware
 * Demo: emits telemetry JSON to Serial. Network transmission is intentionally
 * not enabled until an authenticated ingestion endpoint is configured.
 *
 * Wiring:
 * HC-SR04 VCC -> 5V, GND -> GND, TRIG -> GPIO 5
 * HC-SR04 ECHO -> voltage divider -> GPIO 18 (ESP32 is 3.3V logic!)
 * Example divider: ECHO -- 1kΩ -- GPIO18 -- 2kΩ -- GND
 */
#include <Arduino.h>

const int TRIG_PIN = 5;
const int ECHO_PIN = 18;
const float BIN_DEPTH_CM = 80.0f;
const char* DEVICE_ID = "BC-PAT-001";

float clampFloat(float x, float lo, float hi) {
  return x < lo ? lo : (x > hi ? hi : x);
}

float readDistanceCm() {
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(3);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);
  unsigned long duration = pulseIn(ECHO_PIN, HIGH, 30000UL);
  if (duration == 0) return NAN;
  return duration * 0.0343f / 2.0f;
}

void setup() {
  Serial.begin(115200);
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
}

void loop() {
  float distance = readDistanceCm();
  if (isnan(distance) || distance < 2.0f || distance > BIN_DEPTH_CM + 10.0f) {
    Serial.println("{\"device_id\":\"BC-PAT-001\",\"status\":\"sensor_error\"}");
    delay(5000);
    return;
  }

  float fill = clampFloat((BIN_DEPTH_CM - distance) / BIN_DEPTH_CM * 100.0f, 0.0f, 100.0f);
  // Replace this placeholder with a calibrated sensor reading if a temperature
  // sensor is installed. Do not interpret it as measured temperature.
  const char* temperatureJson = "null";

  Serial.print("{\"device_id\":\"");
  Serial.print(DEVICE_ID);
  Serial.print("\",\"fill_percent\":");
  Serial.print(fill, 1);
  Serial.print(",\"temperature_c\":");
  Serial.print(temperatureJson);
  Serial.print(",\"recorded_at_ms\":");
  Serial.print(millis());
  Serial.println(",\"source\":\"serial_prototype\"}");

  delay(10000);
}
