# BharatClean AI — React dashboard integration

An authenticated, read-only municipal dashboard for Supabase `public.bins` and `public.bin_readings`. It refreshes every 15 seconds and shows fill levels, latest readings, temperature, battery, and source labels.

## Add to your existing repository

Copy the files and folders in this bundle into the root of your existing `Bharatclean-AI` repository. Merge the `supabase/migrations` folder; do not delete your existing migrations or `supabase/functions/ingest-telemetry`.

## Configure environment

```bash
cp .env.example .env.local
```
Set `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` in `.env.local`. Use only the public anon/publishable key. Never place the service-role key or `DEVICE_API_TOKEN` in frontend variables or Git.

## Apply dashboard read policies

```bash
supabase db push
```
The included migration enables RLS and grants authenticated users SELECT access to both tables. It does not grant anonymous access or browser-side writes. For production, replace the broad authenticated read policies with ward- or municipality-scoped policies.

## Run locally

```bash
npm install
npm run dev
```
Open the Vite URL. Create an account or sign in using Supabase Auth. If email confirmation is enabled, confirm the email first.

## Build check

```bash
npm run build
```
Deploy the generated `dist/` folder to a static hosting provider and configure the same two `VITE_` variables in its environment settings.

## Expected schema

`bins`: `id`, `device_id`, `name`, `fill_percent`, `last_seen_at`

`bin_readings`: `bin_id`, `distance_cm`, `temperature_c`, `battery_percent`, `source`, `recorded_at`

The dashboard currently covers authentication, read-only bin telemetry, filtering, and periodic refresh. Citizen reports, route optimization, AI image classification, and ESP32 hardware integration remain subsequent milestones. Simulator data is not physical sensor data.
