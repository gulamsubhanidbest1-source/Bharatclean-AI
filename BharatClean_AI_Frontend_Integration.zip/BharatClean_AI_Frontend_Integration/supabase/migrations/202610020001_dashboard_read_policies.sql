-- Authenticated municipal users can read telemetry. No anonymous access or browser writes.
alter table public.bins enable row level security;
alter table public.bin_readings enable row level security;
do $$ begin
 if not exists (select 1 from pg_policies where schemaname='public' and tablename='bins' and policyname='Authenticated users can read bins') then
  create policy "Authenticated users can read bins" on public.bins for select to authenticated using (true);
 end if;
 if not exists (select 1 from pg_policies where schemaname='public' and tablename='bin_readings' and policyname='Authenticated users can read bin readings') then
  create policy "Authenticated users can read bin readings" on public.bin_readings for select to authenticated using (true);
 end if;
end $$;
