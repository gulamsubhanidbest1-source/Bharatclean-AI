# BharatClean AI — Supabase integration

## Apply the schema
1. Open Supabase Dashboard → SQL Editor.
2. Run `supabase/migrations/202610010001_initial_schema.sql`.
3. Run `supabase/seed.sql` for synthetic Patna demo wards and bins.

## Deploy telemetry Edge Function
Set these in Supabase Edge Function secrets (never in frontend code):
- `SUPABASE_URL`
- `SUPABASE_SERVICE_ROLE_KEY`
- `DEVICE_API_TOKEN`

Then from the project directory:
```bash
supabase login
supabase link --project-ref YOUR_PROJECT_REF
supabase functions deploy ingest-telemetry
```

## Frontend environment
Put only the public URL and anon/publishable key in your local `.env.local`:
```env
VITE_SUPABASE_URL=https://YOUR_PROJECT_REF.supabase.co
VITE_SUPABASE_ANON_KEY=YOUR_PUBLIC_ANON_OR_PUBLISHABLE_KEY
```
Do not commit `.env.local`. Never expose service-role/secret keys in browser code.

## Verify
- Sign up a test user in Supabase Auth; confirm a `profiles` row with role `citizen`.
- Confirm the three demo wards and bins exist.
- Send a telemetry POST to the deployed function with `x-device-token`.
- Confirm a `bin_readings` row and updated `bins.fill_percent` / `last_seen_at`.

All seeded records and simulator readings are synthetic and must remain labelled `demo`.
