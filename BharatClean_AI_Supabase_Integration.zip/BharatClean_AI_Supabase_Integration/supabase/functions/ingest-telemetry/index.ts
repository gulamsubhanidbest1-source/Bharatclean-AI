import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-device-token",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") {
    return Response.json({ error: "Method not allowed" }, { status: 405, headers: corsHeaders });
  }

  const expectedToken = Deno.env.get("DEVICE_API_TOKEN");
  const suppliedToken = req.headers.get("x-device-token");
  if (!expectedToken || !suppliedToken || suppliedToken !== expectedToken) {
    return Response.json({ error: "Unauthorized device" }, { status: 401, headers: corsHeaders });
  }

  const url = Deno.env.get("SUPABASE_URL");
  const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!url || !serviceKey) {
    return Response.json({ error: "Server configuration missing" }, { status: 500, headers: corsHeaders });
  }

  let body: Record<string, unknown>;
  try { body = await req.json(); }
  catch { return Response.json({ error: "Invalid JSON" }, { status: 400, headers: corsHeaders }); }

  const deviceId = typeof body.device_id === "string" ? body.device_id.trim() : "";
  const fill = Number(body.fill_percent);
  const distance = body.distance_cm == null ? null : Number(body.distance_cm);
  const temperature = body.temperature_c == null ? null : Number(body.temperature_c);
  const battery = body.battery_percent == null ? null : Number(body.battery_percent);
  const recordedAt = typeof body.recorded_at === "string" ? body.recorded_at : new Date().toISOString();

  if (!deviceId || !Number.isFinite(fill) || fill < 0 || fill > 100 ||
      (distance !== null && (!Number.isFinite(distance) || distance < 0)) ||
      (temperature !== null && !Number.isFinite(temperature)) ||
      (battery !== null && (!Number.isFinite(battery) || battery < 0 || battery > 100)) ||
      Number.isNaN(Date.parse(recordedAt))) {
    return Response.json({ error: "Invalid device ID, measurement, or timestamp" }, { status: 400, headers: corsHeaders });
  }

  const supabase = createClient(url, serviceKey, {
    auth: { persistSession: false, autoRefreshToken: false },
  });

  const { data: bin, error: lookupError } = await supabase
    .from("bins").select("id").eq("device_id", deviceId).maybeSingle();

  if (lookupError || !bin) {
    return Response.json({ error: "Unknown device_id" }, { status: 404, headers: corsHeaders });
  }

  const { data: reading, error: insertError } = await supabase
    .from("bin_readings")
    .insert({
      bin_id: bin.id, device_id: deviceId, fill_percent: fill,
      distance_cm: distance, temperature_c: temperature,
      battery_percent: battery, recorded_at: recordedAt,
      source: body.source === "live" ? "live" : "demo",
    })
    .select("id, recorded_at, source").single();

  if (insertError) {
    return Response.json({ error: "Could not save reading" }, { status: 500, headers: corsHeaders });
  }

  const { error: updateError } = await supabase.from("bins")
    .update({ fill_percent: fill, last_seen_at: recordedAt }).eq("id", bin.id);

  if (updateError) {
    return Response.json({ error: "Reading saved; bin summary update failed", reading_id: reading.id },
      { status: 500, headers: corsHeaders });
  }
  return Response.json({ ok: true, reading }, { status: 201, headers: corsHeaders });
});
