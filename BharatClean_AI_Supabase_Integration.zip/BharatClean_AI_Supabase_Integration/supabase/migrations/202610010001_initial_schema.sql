-- BharatClean AI: initial schema
create extension if not exists pgcrypto;

create table if not exists public.wards (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  city text not null default 'Patna',
  state text not null default 'Bihar',
  created_at timestamptz not null default now()
);

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  role text not null default 'citizen'
    check (role in ('citizen', 'worker', 'municipal_admin', 'recycler')),
  ward_id uuid references public.wards(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.bins (
  id uuid primary key default gen_random_uuid(),
  device_id text not null unique,
  name text not null,
  ward_id uuid references public.wards(id) on delete set null,
  latitude double precision,
  longitude double precision,
  bin_type text not null default 'mixed'
    check (bin_type in ('wet', 'dry', 'plastic', 'paper', 'mixed', 'hazardous')),
  status text not null default 'active'
    check (status in ('active', 'maintenance', 'offline')),
  fill_percent numeric(5,2) not null default 0 check (fill_percent between 0 and 100),
  last_seen_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.bin_readings (
  id uuid primary key default gen_random_uuid(),
  bin_id uuid not null references public.bins(id) on delete cascade,
  device_id text not null,
  fill_percent numeric(5,2) not null check (fill_percent between 0 and 100),
  distance_cm numeric(8,2) check (distance_cm is null or distance_cm >= 0),
  temperature_c numeric(6,2),
  battery_percent numeric(5,2) check (battery_percent is null or battery_percent between 0 and 100),
  recorded_at timestamptz not null default now(),
  source text not null default 'demo' check (source in ('demo', 'live')),
  created_at timestamptz not null default now()
);

create table if not exists public.citizen_reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references auth.users(id) on delete cascade,
  ward_id uuid references public.wards(id) on delete set null,
  category text not null check (category in
    ('overflowing_bin', 'litter', 'illegal_dumping', 'drain_blockage', 'missed_collection', 'other')),
  description text not null,
  latitude double precision,
  longitude double precision,
  image_url text,
  status text not null default 'submitted'
    check (status in ('submitted', 'verified', 'assigned', 'resolved', 'rejected')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.collection_jobs (
  id uuid primary key default gen_random_uuid(),
  bin_id uuid references public.bins(id) on delete set null,
  ward_id uuid references public.wards(id) on delete set null,
  assigned_to uuid references auth.users(id) on delete set null,
  status text not null default 'pending'
    check (status in ('pending', 'assigned', 'in_progress', 'completed', 'cancelled')),
  scheduled_for timestamptz,
  completed_at timestamptz,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists bins_ward_idx on public.bins(ward_id);
create index if not exists readings_bin_recorded_idx on public.bin_readings(bin_id, recorded_at desc);
create index if not exists reports_status_created_idx on public.citizen_reports(status, created_at desc);
create index if not exists reports_reporter_idx on public.citizen_reports(reporter_id, created_at desc);
create index if not exists jobs_status_scheduled_idx on public.collection_jobs(status, scheduled_for);

create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end;
$$;

do $$
declare t text;
begin
  foreach t in array array['profiles','bins','citizen_reports','collection_jobs'] loop
    execute format('drop trigger if exists %I_updated_at on public.%I', t, t);
    execute format('create trigger %I_updated_at before update on public.%I for each row execute function public.set_updated_at()', t, t);
  end loop;
end $$;

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = ''
as $$
begin
  insert into public.profiles (id, full_name)
  values (new.id, coalesce(new.raw_user_meta_data ->> 'full_name', ''));
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute function public.handle_new_user();

create or replace function public.current_user_role()
returns text language sql stable security definer set search_path = ''
as $$ select role from public.profiles where id = auth.uid() $$;

alter table public.wards enable row level security;
alter table public.profiles enable row level security;
alter table public.bins enable row level security;
alter table public.bin_readings enable row level security;
alter table public.citizen_reports enable row level security;
alter table public.collection_jobs enable row level security;

drop policy if exists "wards readable by authenticated users" on public.wards;
create policy "wards readable by authenticated users" on public.wards
for select to authenticated using (true);

drop policy if exists "profile readable by owner or admin" on public.profiles;
create policy "profile readable by owner or admin" on public.profiles
for select to authenticated using (id = auth.uid() or public.current_user_role() = 'municipal_admin');

drop policy if exists "bins readable by authenticated users" on public.bins;
create policy "bins readable by authenticated users" on public.bins
for select to authenticated using (true);

drop policy if exists "readings readable by authenticated users" on public.bin_readings;
create policy "readings readable by authenticated users" on public.bin_readings
for select to authenticated using (true);

drop policy if exists "citizens create own reports" on public.citizen_reports;
create policy "citizens create own reports" on public.citizen_reports
for insert to authenticated with check (reporter_id = auth.uid());

drop policy if exists "reporter or municipal team reads reports" on public.citizen_reports;
create policy "reporter or municipal team reads reports" on public.citizen_reports
for select to authenticated using (
  reporter_id = auth.uid() or public.current_user_role() in ('municipal_admin', 'worker')
);

drop policy if exists "municipal team updates reports" on public.citizen_reports;
create policy "municipal team updates reports" on public.citizen_reports
for update to authenticated
using (public.current_user_role() in ('municipal_admin', 'worker'))
with check (public.current_user_role() in ('municipal_admin', 'worker'));

drop policy if exists "collection jobs readable by team" on public.collection_jobs;
create policy "collection jobs readable by team" on public.collection_jobs
for select to authenticated using (
  public.current_user_role() in ('municipal_admin', 'worker')
  and (public.current_user_role() = 'municipal_admin' or assigned_to = auth.uid())
);

drop policy if exists "municipal admins manage collection jobs" on public.collection_jobs;
create policy "municipal admins manage collection jobs" on public.collection_jobs
for all to authenticated
using (public.current_user_role() = 'municipal_admin')
with check (public.current_user_role() = 'municipal_admin');

-- No browser-facing insert/update policy exists for bins or bin_readings.
-- The telemetry Edge Function writes with its server-side service role key.
