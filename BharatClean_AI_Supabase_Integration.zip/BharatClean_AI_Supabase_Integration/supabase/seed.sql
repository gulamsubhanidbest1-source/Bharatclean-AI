-- Synthetic Patna demo records only; not deployed municipal assets.
insert into public.wards (name, city, state) values
('Kankarbagh', 'Patna', 'Bihar'),
('Rajendra Nagar', 'Patna', 'Bihar'),
('Patna City', 'Patna', 'Bihar')
on conflict (name) do nothing;

insert into public.bins (device_id, name, ward_id, bin_type, status)
select v.device_id, v.name, w.id, v.bin_type, 'active'
from (values
  ('BC-KBK-001', 'Kankarbagh Demo Bin 01', 'Kankarbagh', 'mixed'),
  ('BC-RJN-001', 'Rajendra Nagar Demo Bin 01', 'Rajendra Nagar', 'dry'),
  ('BC-PC-001', 'Patna City Demo Bin 01', 'Patna City', 'wet')
) as v(device_id, name, ward_name, bin_type)
join public.wards w on w.name = v.ward_name
on conflict (device_id) do nothing;
